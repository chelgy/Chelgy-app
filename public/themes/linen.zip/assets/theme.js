document.querySelector('.menu-btn')?.addEventListener('click', function(){
  var nav = document.querySelector('nav.main');
  if(!nav) return;
  var open = nav.style.display === 'flex';
  nav.style.cssText = open ? '' : 'display:flex;flex-direction:column;position:absolute;top:96px;left:20px;gap:14px;background:var(--cream);padding:20px 26px;border:1px solid var(--line-soft);z-index:30;';
});
